export class Status {
  title: String;
  year: String;
  director: String;
  cast: String
  genre: String;
  notes: String;
  recording:boolean;
  image:String;
}