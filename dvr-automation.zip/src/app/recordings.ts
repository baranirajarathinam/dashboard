export class Recordings {
  title: String;
  year: String;
  director: String;
  cast: String
  genre: String;
  notes: String;
  videoUrl:String;
  image:String;
  recordedDate:String;  
}