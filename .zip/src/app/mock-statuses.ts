import { Status } from './status';

export const STATUSES: Status[] = [
  {
    title: 'Alice in Wonderland: Through the Looking Glass',
    year: '2016',
    director: 'James Bobin',
    cast: 'Mia Wasikowska, Johnny Depp, Helena Bonham Carter, Anne Hathaway',
    genre: 'Fantasy',
    notes: 'Walt Disney Pictures, Based on the novel Through the Looking-Glass (1971) by Lewis Carroll, Sequel to Alice in Wonderland (2010)',
    recording:false
  },
  {
    title: 'Finding Dory',
    year: '2016',
    director: 'Andrew Stanton',
    cast: 'Ellen DeGeneres, Albert Brooks, Diane Keaton, Eugene Levy',
    genre: 'Animation, Adventure',
    notes: 'Walt Disney Pictures, Sequel to Finding Nemo (2003)',
    recording:false

  },
  {
    title: 'Angry Birds',
    year: '2016',
    director: 'Clay Kaytis',
    cast: 'Jason Sudeikis, Josh Gad, Bill Hader, Peter Dinklage',
    genre: 'Animation, Action',
    notes: 'Columbia Pictures, Based on the video game of the same name',
    recording:false
  },
  {
    title: 'Dirty Grandpa',
    year: '2016',
    director: 'Dan Mazer',
    cast: 'Zac Efron, Robert De Niro, Zoey Deutch, Aubrey Plaza',
    genre: 'Comedy',
    notes: 'Lions Gate Entertainment',
    recording:false
  },
  {
    title: 'The Jungle Book',
    year: '2016',
    director: 'Jon Favreau',
    cast: 'Bill Murray, Ben Kingsley, Idris Elba',
    genre: 'Adventure',
    notes: 'Walt Disney Pictures, Based on the story of the same name by Rudyard Kipling',
    recording:true
  },
  {
    title: 'Geostorm',
    year: '2016',
    director: 'Dean Devlin',
    cast: 'Gerard Butler, Andy Garcia, Ed Harris, Katheryn Winnick',
    genre: 'Action',
    notes: 'Warner Bros.'	,
    recording:true
	
  }
];